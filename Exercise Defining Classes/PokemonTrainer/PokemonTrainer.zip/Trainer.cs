﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace PokemonTrainer
{
    public class Trainer
    {
        public string Name { get; set; }
        public int Badgets { get; set; }
        Dictionary<string,List<Pokemon>> pokemons =new Dictionary<string, List<Pokemon>>();
        public Trainer(string name,Pokemon pokemon/*,string pokemonName,string pokemonEl,int health*/)
        {
            this.Name = name;
            //pokemon.Name = pokemonName;
            //pokemon.Element= pokemonEl;
            //pokemon.Health= health;
            if (!pokemons.ContainsKey(name))
            {
                pokemons[name] = new List<Pokemon>();
            }
            pokemons[name].Add(pokemon);
        }

    }
}
