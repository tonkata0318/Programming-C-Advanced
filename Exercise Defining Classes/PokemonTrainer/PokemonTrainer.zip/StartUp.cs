﻿using System.Globalization;

namespace PokemonTrainer
{
    public  class StartUp
    {
        static void Main(string[] args)
        {
            string input=Console.ReadLine();
            Dictionary<string, List<Pokemon>> pokemons = new Dictionary<string, List<Pokemon>>();
            Dictionary<string, int> badgetsForName = new Dictionary<string, int>();
            while (input!= "Tournament")
            { 
                Pokemon pokemon= new Pokemon();
                string[] inputInfo = input.Split(" ",StringSplitOptions.RemoveEmptyEntries);
                string trainerName = inputInfo[0];
                string pokemonName = inputInfo[1];
                string pokemonEl = inputInfo[2];
                int pokemonhealth = int.Parse(inputInfo[3]);
                pokemon.Name= pokemonName;
                pokemon.Element= pokemonEl;
                pokemon.Health= pokemonhealth;
                Trainer trainer = new Trainer(trainerName,pokemon/*pokemonName,pokemonEl,pokemonhealth*/);
                if (!pokemons.ContainsKey(trainerName))
                {
                    pokemons[trainerName] = new List<Pokemon>();
                }
                pokemons[trainerName].Add(pokemon);
                input = Console.ReadLine();
            }
            string command = Console.ReadLine();
            badgetsForName = new Dictionary<string, int>();
            foreach (var item in pokemons)
            {
                badgetsForName.Add(item.Key, 0);
            }
            while (command!="End")
            {
                bool heHas = false;
                foreach (var trainer in pokemons)
                {
                    heHas = false;
                    foreach (var pokemon in trainer.Value)
                    {
                        if (pokemon.Element==command)
                        {
                            badgetsForName[trainer.Key]++;
                            heHas = true;
                        }
                        
                    }
                    if (heHas==false)
                    {
                        foreach (var pokemon in trainer.Value)
                        {
                            pokemon.Health -= 10;
                            if (pokemon.Health<=0)
                            {
                                pokemons[trainer.Key].Remove(pokemon);
                                if (pokemons[trainer.Key].Count<=0)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                command = Console.ReadLine();
            }
            foreach (var item in badgetsForName.OrderByDescending(x=>x.Value))
            {
                Console.WriteLine($"{item.Key} {item.Value} {pokemons[item.Key].Count}");
            }
        }
    }
}